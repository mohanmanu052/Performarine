import 'package:flutter/material.dart';

class UrlModel
{
  String? version;


}