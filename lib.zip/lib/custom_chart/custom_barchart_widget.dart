import 'package:flutter/material.dart';
import 'package:performarine/common_widgets/utils/colors.dart';
import 'package:performarine/common_widgets/utils/common_size_helper.dart';
import 'package:performarine/common_widgets/utils/constants.dart';
import 'package:performarine/custom_chart/animated_barchart.dart';
import 'package:performarine/new_trip_analytics_screen.dart';

class CustomBarChartWidget extends StatelessWidget {
  final List<SalesData> data;

  CustomBarChartWidget({required this.data});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Container(
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.only(left: 10, right: 10),
        width: data.length * 100.0, // Adjust this value to control the width of the chart
        //width:displayWidth(context), // Adjust this value to control the width of the chart
        //height: 300,
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Row(
                  children: [
                    Container(
                      width: 14,
                      height: 14,
                      color: blueColor,
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text('Total Duration', style: TextStyle(color: Colors.black, fontSize: 10,  fontFamily: outfit),)
                  ],
                ),
                SizedBox(
                  width: 10,
                ),
                Row(
                  children: [
                    Container(
                      width: 14,
                      height: 14,
                      color: Color(0xFF67C6C7),
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text('< 5KT>', style: TextStyle(color: Colors.black, fontSize: 10,  fontFamily: outfit),)
                  ],
                ),
              ],
            ),
            AnimatedBarChart(data: data),
          ],
        ),
      ),
    );
  }
}