import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as fm;
import 'package:performarine/common_widgets/utils/colors.dart';
import 'package:performarine/common_widgets/utils/constants.dart';
import 'package:performarine/new_trip_analytics_screen.dart';


class BarChartPainter1 extends CustomPainter {
  final List<SalesData> data;
  final double animationValue;

  BarChartPainter1(this.data, this.animationValue);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.fill;

    Paint barPaint = Paint()
      ..style = PaintingStyle.fill;

    final double barWidth = 32;
    final double spacing = 4.5;
    final double groupSpacing = 30;
    //final double chartHeight = size.height - 20; // leave some padding at the top and bottom
    final double chartHeight =
        size.height - 80; // leave some padding at the top and bottom
    //final double fixedBlueBarHeight = chartHeight * 0.7; // Set a fixed height for blue bars
    final double fixedBlueBarHeight =
        chartHeight * 0.85; // Set a fixed height for blue bars
    final double gapBetweenBars = 4;

    // Draw x-axis
    final axisPaint = Paint()
      ..color = Colors.black
      ..strokeWidth = 1;
    final double xAxisY = size.height - 40; // Adjust this value to control the position of the x-axis
    canvas.drawLine(Offset(0, xAxisY), Offset(size.width, xAxisY), axisPaint);

    for (int i = 0; i < data.length; i++) {
      final x = i * (2 * barWidth + spacing + groupSpacing);

      // Calculate heights for red and green bars
      final double barHeight2 =
          fixedBlueBarHeight * (data[i].speedDuration / data[i].totalDuration);
      final double difference = (data[i].totalDuration - data[i].speedDuration).abs();
      final double barHeightDiff =
          fixedBlueBarHeight * (difference / data[i].totalDuration);

      // Adjust blue bar height if value2 is 0.0
      final double adjustedBlueBarHeight = data[i].speedDuration == 0.0
          ? fixedBlueBarHeight + gapBetweenBars
          : fixedBlueBarHeight + gapBetweenBars;
      // Draw first bar (blue) with adjusted height
      paint.color = blueColor;
      canvas.drawRect(
        Rect.fromLTWH(
            x,
            size.height - adjustedBlueBarHeight * animationValue - 40,
            barWidth,
            adjustedBlueBarHeight * animationValue),
        paint,
      );

      // Draw the red bar
      paint.color = Color(0xFF67C6C7);
      canvas.drawRect(
        Rect.fromLTWH(
            x + barWidth + spacing,
            size.height - barHeight2 * animationValue - 40,
            barWidth,
            barHeight2 * animationValue),
        paint,
      );


      if (data[i].speedDuration != 0.0) {
        // Draw the green bar only if value2 is not 0.0
        final double yPositionDiff = size.height - barHeight2 * animationValue - barHeightDiff * animationValue - gapBetweenBars - 40;
        paint.color = Colors.yellow;
        canvas.drawRect(
          Rect.fromLTWH(x + barWidth + spacing, yPositionDiff, barWidth, barHeightDiff * animationValue),
          paint,
        );

        // Draw labels on top of the green difference bar
        final valueTextDiff = TextSpan(
          text: difference == 0 || difference < 0 ? '' : difference.toStringAsFixed(2),
          style: TextStyle(color: Colors.black, fontSize: 10, fontFamily: outfit),
        );
        final textPainterDiff = TextPainter(
          text: valueTextDiff,
          textDirection: TextDirection.ltr,
        );
        textPainterDiff.layout();
        textPainterDiff.paint(
          canvas,
          Offset(x + barWidth + spacing + barWidth / 2 - textPainterDiff.width / 2, yPositionDiff - 0),
        );
      }

      // Draw labels on top of the blue bar
      final valueText1 = TextSpan(
        text: data[i].totalDuration == 0 || data[i].totalDuration < 0 ? '' : data[i].totalDuration.toStringAsFixed(2),
        style: TextStyle(color: Colors.white, fontSize: 10,  fontFamily: outfit),
      );
      final textPainter1 = TextPainter(
        text: valueText1,
        textDirection: TextDirection.ltr,
      );
      textPainter1.layout();
      textPainter1.paint(
        canvas,
        Offset(x + barWidth / 2 - textPainter1.width / 2, size.height - adjustedBlueBarHeight * animationValue - 35),
      );

      // Draw labels inside the red bar at the top
      final valueText2 = TextSpan(
        text: data[i].speedDuration == 0 || data[i].speedDuration < 0 ? '' : data[i].speedDuration.toStringAsFixed(2),
        style: TextStyle(color: Colors.black, fontSize: 10,  fontFamily: outfit),
      );
      final textPainter2 = TextPainter(
        text: valueText2,
        textDirection: TextDirection.ltr,
      );
      textPainter2.layout();
      textPainter2.paint(
        canvas,
        Offset(x + barWidth + spacing + barWidth / 2 - textPainter2.width / 2, size.height - barHeight2 * animationValue - 40 + 5),
      );

      // Draw date label at the bottom center of the group of bars
      var parse = fm.DateFormat('yyyy-MM-dd').format(data[i].year);
      final dateText = TextSpan(
        text: parse.toString(),
        style: TextStyle(color: Colors.black, fontSize: 11, fontFamily: outfit),
      );
      final textPainter = TextPainter(
        text: dateText,
        textDirection: TextDirection.ltr,
      );
      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(x + (barWidth + spacing + barWidth) / 2 - textPainter.width / 2, size.height - 35),
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}