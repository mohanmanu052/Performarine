import 'package:flutter/material.dart';
import 'package:performarine/common_widgets/utils/colors.dart';
import 'package:performarine/common_widgets/utils/common_size_helper.dart';
import 'dart:math' as math;

import 'package:performarine/common_widgets/widgets/common_widgets.dart';

import '../utils/constants.dart';

//To show dashed rectangle
class DashedRect extends StatelessWidget {
  final Color? color;
  final double? strokeWidth;
  final double? gap;
  final Function()? onTap;
  final String? title;
  final Color? backgroundColor, primaryTextColor;

  DashedRect(
      {this.color = Colors.black,
      this.strokeWidth = 1.0,
      this.gap = 5.0,
      this.onTap,
      this.title,
      this.primaryTextColor,
      this.backgroundColor});

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      color: backgroundColor,
      child: Padding(
        padding: EdgeInsets.all(strokeWidth! / 1),
        child: CustomPaint(
          painter: DashRectPainter(
              color: color!, strokeWidth: strokeWidth!, gap: gap!),
          child: MaterialButton(
            onPressed: onTap,
            child: Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: displayWidth(context) * 0.05),
                  child: Icon(
                    Icons.file_upload_outlined,
                    color: blueColor,
                  ),
                ),

                SizedBox(
                  width: displayWidth(context) * 0.02,
                ),

                commonText(
                  text: title!,
                  context: context,
                  textSize: displayWidth(context) * 0.04,
                  textColor: Theme.of(context).brightness == Brightness.dark
                  ? primaryTextColor!
                  : blueColor,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Inter'
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

//To show dashed rectangle
class DashedRectToUploadImage extends StatelessWidget {
  final Color? color;
  final double? strokeWidth;
  final double? gap;
  final Function()? onTap;
  final String? title;
  final Color? backgroundColor, primaryTextColor;

  DashedRectToUploadImage(
      {this.color = Colors.black,
        this.strokeWidth = 1.0,
        this.gap = 5.0,
        this.onTap,
        this.title,
        this.primaryTextColor,
        this.backgroundColor});

  @override
  Widget build(
      BuildContext context,
      ) {
    return Container(
      color: backgroundColor,
      child: Padding(
        padding: EdgeInsets.all(strokeWidth! / 1),
        child: CustomPaint(
          painter: DashRectPainter(
              color: color!, strokeWidth: strokeWidth!, gap: gap!),
          child: MaterialButton(
            onPressed: onTap,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/images/upload_image.png',
                    height: displayHeight(context) * 0.059,
                    width: displayWidth(context) * 0.18,
                  ),
                  commonText(
                    text: title!,
                    context: context,
                    textSize: displayWidth(context) * 0.033,
                    textColor: Theme.of(context).brightness == Brightness.dark
                        ? primaryTextColor!
                        : blueColor,
                    fontWeight: FontWeight.w500,
                    fontFamily: outfit
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class DashRectPainter extends CustomPainter {
  double strokeWidth;
  Color color;
  double gap;

  DashRectPainter(
      {this.strokeWidth = 5.0, this.color = Colors.red, this.gap = 5.0});

  @override
  void paint(Canvas canvas, Size size) {
    Paint dashedPaint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    double x = size.width;
    double y = size.height;

    Path _topPath = getDashedPath(
      a: math.Point(0, 0),
      b: math.Point(x, 0),
      gap: gap,
    );

    Path _rightPath = getDashedPath(
      a: math.Point(x, 0),
      b: math.Point(x, y),
      gap: gap,
    );

    Path _bottomPath = getDashedPath(
      a: math.Point(0, y),
      b: math.Point(x, y),
      gap: gap,
    );

    Path _leftPath = getDashedPath(
      a: math.Point(0, 0),
      b: math.Point(0.001, y),
      gap: gap,
    );

    canvas.drawPath(_topPath, dashedPaint);
    canvas.drawPath(_rightPath, dashedPaint);
    canvas.drawPath(_bottomPath, dashedPaint);
    canvas.drawPath(_leftPath, dashedPaint);
  }

  Path getDashedPath({
    required math.Point<double> a,
    required math.Point<double> b,
    required gap,
  }) {
    Size size = Size(b.x - a.x, b.y - a.y);
    Path path = Path();
    path.moveTo(a.x, a.y);
    bool shouldDraw = true;
    math.Point currentPoint = math.Point(a.x, a.y);

    num radians = math.atan(size.height / size.width);

    num dx = math.cos(radians) * gap < 0
        ? math.cos(radians) * gap * -1
        : math.cos(radians) * gap;

    num dy = math.sin(radians) * gap < 0
        ? math.sin(radians) * gap * -1
        : math.sin(radians) * gap;

    while (currentPoint.x <= b.x && currentPoint.y <= b.y) {
      shouldDraw
          ? path.lineTo(currentPoint.x.toDouble(), currentPoint.y.toDouble())
          : path.moveTo(currentPoint.x.toDouble(), currentPoint.y.toDouble());
      shouldDraw = !shouldDraw;
      currentPoint = math.Point(
        currentPoint.x + dx,
        currentPoint.y + dy,
      );
    }
    return path;
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
