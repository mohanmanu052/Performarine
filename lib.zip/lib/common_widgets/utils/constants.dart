
const poppins = "Poppins";
const inter = "Inter";
const reemKufi = "ReemKufiInk";
const outfit = "Outfit";
const dmsans="DMSans";

const nauticalMile = 'NM';
const knot = 'KT';
const speedKnot = 'KT/h';
const liters='L';
const watt='W';
const litre = 'l';
const kiloWattHour = 'kWh';
const feet = 'ft';
const year = 'YYYY';
const hp = 'hp';
const pound = 'lb';
const cubicCapacity = 'cc';

String logLevel = "info";

