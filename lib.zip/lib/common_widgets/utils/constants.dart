
const poppins = "Poppins";
const inter = "Inter";
const reemKufi = "ReemKufiInk";
const outfit = "Outfit";
const dmsans="DMSans";

const nauticalMile = 'NM';
const knot = 'KT';
const speedKnot = 'KT/h';
const liters='L';
const watt='W';
//const litre = 'l';
const kiloWattHour = 'kWh';
const feet = 'ft';
const year = 'YYYY';
const hp = 'hp';
const pound = 'lb';
const cubicCapacity = 'cc';
const gallons = 'gal';
const kg = 'kg';
const cad = 'CAD';
const nauticalMiles = 'Nautical Miles';
const meters = 'meters';
const knots = 'KT';
const cardinal = 'T';
const minutes = 'Minutes';
const knotReport = 'Knots';
const literReport = 'Liters';
const watsReport = 'Wats';

String logLevel = "info";

const lastTimeUsedText = 'Last time you used performarine, there was a trip in progress. Do you want to end the trip or continue?';
const deleteTripSubText = 'This action is irreversible. Do you want to delete it?';
const endTripSubText = 'Are you sure you want to end the trip?';

